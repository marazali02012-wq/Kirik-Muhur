# CLAUDE — KIRIK MÜHÜR RPG / KESİN GELİŞTİRME VE ONARIM KOMUTU

## İŞİN
`marazali02012-wq/Kirik-Muhur` deposundaki Kırık Mühür RPG oyununu kullanıcının kesin şartnamesiyle tutarlı biçimde geliştireceksin. Bu paketteki `Kirik_Muhur_3_24_KAYNAK_TEST.html` senin başlangıç dosyandır. Kullanıcının önceliği **aşamaları sırayla gerçek anlamda tamamlamak; hatayı çözdüğünü kanıtlamadan sonraki aşamaya atlamamak**. İşi bitirdiğini varsayma; önce kodu ve testleri gerçekten çalıştır.

### Yetkili kaynak sırası
1. **Kullanıcının kesin şartnamesi:** `docs/KIRIK_MUHUR_KULLANICI_KESIN_SARTNAME.md` (main)
   https://github.com/marazali02012-wq/Kirik-Muhur/blob/main/docs/KIRIK_MUHUR_KULLANICI_KESIN_SARTNAME.md
2. **Aşama kilidi / uygulama kararları:** `docs/KIRIK_MUHUR_PROJE_OMURGASI_KARAR_2026-11-19.md`
   https://github.com/marazali02012-wq/Kirik-Muhur/blob/main/docs/KIRIK_MUHUR_PROJE_OMURGASI_KARAR_2026-11-19.md
3. **Kaynak HTML:** bu ZIP içindeki `Kirik_Muhur_3_24_KAYNAK_TEST.html`, GitHub `stage3-reward-ui-314/Kirik_Muhur_3_24_Gelisim_Omurgasi_TEST.html`, Git blob SHA `b70de48f729e77fdd924711001ada641cb39b2d5`.
4. **Görsel referanslar:** `referanslar/` ve `docs/KIRIK_MUHUR_4_GORSEL_REFERANSI.md`.

Şartnamede netleşmemiş bir konuda kendi varsayımını kullanıcı talimatı sayma. Buradaki önceki kesin kararlar geçerlidir: çiçek joystick değildir; ödül NPC'ye dönüşte otomatik **bir kez** eklenir, popup yalnız bilgilendirir, ikinci 'ÖDÜLÜ AL / SONRA AL' sorusu yoktur.

## KORUMA KURALLARI — ZORUNLU
- `main/index.html` dosyasını, 3.19–3.24 eski sürümlerini, oynanabilir son sürümü, diğer oyun projelerini, Supabase veritabanını, Play Console'u ve canlı sunucuları **değiştirme**. Kendi ayrı 3A çalışma dalında ve yeni test HTML adıyla ilerle.
- Kayıt anahtarlarını rastgele değiştirme; kaynakta `kirikMuhurQuestFlowV324Test` kullanılıyor. Önceki `V323Test`, `V32` vb. kayıtları silme ve üzerine yazma; uyumlu, bir defalık, doğrulanabilir geçiş gerekiyorsa raporla.
- Tek HTML / Android portre modunu bozma. Kod sadeleştirmek adına görev, çanta, savaş, harita, çiçek menü, güç/XP ve üç sınıftan özellik silme.
- Arena Forge Pro'ya dokunma. Telifli Kung Fu Saga arayüz/varlık/kodunu kopyalama; sadece mekanik ve ekran oranlarını **referans al**, özgün görseller kullan.
- Sırf buton veya popup görüldü diye sistemi çalışıyor sayma. İlerleme, güç/stat hesapları ve kayıtların gerçek davranışını denetle.
- 'AAA', 'kusursuz', 'Android onaylandı', 'MMORPG aktif' gibi doğrulanmamış iddialar yazma. Gerçek çok oyunculu dünya için ayrı sunucu, eşzamanlı ağ/kimlik ve veri tabanı gerekir.

## MEVCUT DURUM — DOĞRULANAN VE AÇIK OLANI AYIR
- **Mevcut test:** 3 sınıf; 3 bölge (Fener Köyü, Ruh Ormanı, Kırık Tapınak); 10 hikâye + 5 dönüşümlü görev; 3 yan hedef; temel otomatik/manuel savaş; XP/level; çanta ve 3 ödül ekipmanı; gelişim/BP ekranı; sağ altta çiçek menü. Bunlar başlangıç seviyesinde.
- **Açık sorunlar:** gerçek Android dokunma ve uzun süre testi yok; gerçek site origin'inde oyunu kapatıp açınca `localStorage` doğrulanmadı; nadir rota/dönüş/ölüm/ödül çoklama ihtimalleri; ödül popup'ının görev tesliminde **fiilen ve otomatik** açılması doğrulanmadı; eski başlangıç metinlerinde ayrı etkileşimden bahseden açıklamalar olabilir.
- **Büyük açıklar (şimdi değil, ilgili aşamada):** yeni biyom/yaratık çeşitliliği, daha güçlü hikâye, seviye/ekonomi dengesi, yetenek açılma ağacı, gerçek pet/binek eğitimi, erkek/kadın karakter oluşturma ve büyük önizleme, kaliteli sahneler/HUD, şehir hub. Zindan/world boss/lonca/PvP/günlük ve online sosyal sistemler ileriki aşamalardır.

# AŞAMA 3A — ŞİMDİ TEK İŞİN BU, ÖNCE TAMAMLA

### 3A.1 Kod tabanı ve kök neden denetimi
1. HTML'i oku; tek `<script>` ile DOM/CSS/Canvas sıralamasını çıkar. `missionInfo`, `questAction`, `autoMissionTick`, `deliverMissionAtNPC`, `questAward`, `goTo`, portal/bölge geçişi, `save`, `load`, `restore`, `enterZone`, manuel touch/pointer kontrol akışını izle.
2. Hareketin sağ/sol/diyagonal dönüşünü, yürüyüş animasyon karelerini, hedef çevresinde titremeyi, rota köşeleri/duvarlar/portallar, karakterin NPC'yi yakalayamaması ve `autoPath` ile `autoBattle` arasındaki durum geçişlerini kök nedenden düzelt.
3. Oyuncu manuel hareketle kontrolü devralınca otomatik hareket ve savaş kendiliğinden açılmamalı. Göreve tekrar dokununca açık görev kaldığı yerden sürmeli.
4. Görev hedefi doğruysa otomatik savaş ve sahne değişimi çalışmalı; yanlış/boş hedef veya düşmanın ölmesi görev durumunu kilitlememeli. Haritadaki gerçek nesne konumu ile hedef işaretleri çelişmemeli.
5. NPC'ye güvenli mesafede dönünce ödül **tek kez** kredilensin; **ödül bilgilendirme popup'ı** altın, XP, ruh tozu ve varsa eşya/güç değişimini göstersin; oyuncuya ikinci onay sormasın. `questRewards` ve `side324` gibi muhasebe kimliklerini koru. Popup varsa eski bir ödül penceresinin yanlış fonksiyona bağlı olup olmadığını incele. Duplicate reward/çift item olamaz.
6. Oyunu duraklatma, ölüm, yarım görevde bölgeden çıkma, savaştan kaçma, otomatik av sırasında envanter açma, harita üzerinden yanlış bölgeye gitme ve portal dönüşü durumları için durum makinesi çizip test et. Oyuncu manuel oynayabilmeli.
7. Alt sağ çiçek **menü değiştirici/gizleyicidir**; joystick olarak davranamaz. Çiçeği döndürme/çevirme ile sayfa değişimi işlevli olsun; fiziksel hareket ayrı.
8. Ekran yazılarını mevcut davranışla eşleştir. Yalnızca arayüzde görünür ama çalışmayan 'ödül', 'otomatik görev' vb. gösterme.

### 3A.2 Kalıcılık (özellikle güçlü test)
- Tarayıcı gerçek origin'inde kullanıcı oluştur, seviye/görev/XP/altın/eşya/ekipman/güç, NPC teslimi, manuel-oto kontrol durumlarını yaz; tarayıcı sekmesini/uygulamayı kapatıp yeni sekmede aç; alanların **birebir** döndüğünü doğrula. Sahte `localStorage` testi yaparsan bunu ayrıca belirt, gerçek diskli kayıt testi olarak sunma.
- Eski sürüm kayıtlarından test verisiyle geçiş dene; ana kullanıcı kaydını silme. Kaydı geri yüklerken ödül yeniden işlenmemeli, `questPhase` kilitlenmemeli, silah/HP/stat tutarlılığı korunmalı.
- Kayıt bozulmuşsa oyunun tümden çökmesini engelle; güvenli kurtarma bildirimi göster, asıl veriyi izinsiz silme.

### 3A.3 Test matrisi — geçmeden 3B açma
- **Portre:** 320×568, 360×800, 393×852, 412×915; mobil dokunmatik emülasyon. HUD taşma, gereksiz şeffaf çizgi, buton çakışması, yanlış tıklama, karakter görünürlüğü kontrolü; önce/sonra ekran görüntüsü.
- **Sınıflar:** Muhafız, İzci, Dokumacı için her birinde en az ilk iki ana görev, yanlış bölge, manuel kesme/devam, ödülün tek olması, savaş hasarı, ölüm ve respawn, çiçek menü.
- **Oyun akışı:** 10 ana görev + 3 yan hedef + 5 devam görevi; her birinin tetikleyici ve NPC teslimi, geçişi, ödül hesabı. 3.24'ün çalışan ilerleyişi korunmalı.
- **Gerçek cihaz:** Android'de dokunmatik, geri tuşu, dikey görünüm, FPS, yakınlaşma, ekran taşması, başlangıçta siyah ekran, uzun oturum. Cihaza erişimin yoksa 'YAPILAMADI — kullanıcı Android kabulü gerekli' yaz; başarısız test varmış gibi gösterme.
- Hata denetimi: JS sözdizimi, console/pageerror, çifte etkileşim, 30 dakika oyun veya erişilebilen en uzun gerçek süre (süreyi ve ortamı açık yaz), save/load tekrarları.
- Her hatayı kök neden + değişen satır/işlev + test kanıtı ile raporla. 3A bu matriste doğrulanmadan **3B, 3C, 3D, 3E veya 4. aşamaya geçme**.

# SONRAKİ AŞAMALAR — SADECE 3A TAM KABUL EDİLDİĞİNDE

### 3B — Harita / görev (çalışan tabanı genişlet)
- Gerçek bölge açılma koşulları, çeşitli NPC'ler, savaş/toplama/keşif/yazıt görevleri, yaratık tipleri ve konumları, bossun yalnız hikâyeye bağlı kullanımı, harita rota testleri.
- Aynı 3 canavarı ve aynı dönüş yolunu aralıksız tekrarlatan yapı yok. Yeni bölgeler özgün sahnelerle, çizim/çarpışma eşleşerek eklensin. İçerik katmanını mevcut görev motorundan ayır; kapalı görevler açık görünmesin.

### 3C — Seviye / beceri / ekonomi
- XP eşikleri, seviyeye göre açılan ve yükseltilen aktif/pasif beceriler, bedeli gerçek kaynaklardan düşülen forge, nadirlik/drop, seviye kontrollü ekipman, güç puanı hesapları, pet/binek seviyeleri ve stat etkileri. XP/enflasyon/hasar/HP dengesi için birim ve gerçek oyun testleri.

### 3D — Uzun regresyon
- Eski kayıt geçişi, gerçek tarayıcı kalıcı kayıt, sınıf/cihaz/bölge/ödül/ekonomi/performans, Android 30+ dakika, yeniden açma ve hiç veri kaybetmeme.

### 3E — Görsel kalite / giriş / HUD / şehir
- Erkek/kadın görünüm seçimi, sınıf önizlemesi, tematik arka plan, adım adım Sonraki Adım/Next Step akışı. HUD: üst sol profil+seviye+güç; üst kaynaklar; sağ bölge/koordinat; sol görev; alt beceri, çanta/karakter/pet/forge kısayolları; çiçek gizli menü. Sahne/karakter/orijinal animasyonlar kullanıcı pixel-art kalite örneklerine benzer ışık/katman ve net konturda. Şehir NPC/hub gerçek mekânsal bağlantılara sahip olmalı. Gerçek ekonomi yoksa sahte premium para/VIP, gerçek chat yoksa sahte sohbet gösterme.

### Aşama 4+ (ŞİMDİ BAŞLAMA)
- Ayrı boss/dungeon, ganimet ve girişler; daha sonra hesap tabanlı gerçek lonca/sohbet/PvP; günlük etkinlik/market/premium. Backend gerektirir; sadece boş menü yapma.

# HER TAMAMLANAN AŞAMADA TESLİM ZORUNLULUĞU
1. Yeni tek dosyalı oynanabilir HTML (kaynakla aynı ya da daha yüksek işlevsellik), test dosyaları ve değişiklik raporu.
2. ZIP: `HTML + TEST_RAPORU.md + DEGİSİKLİKLER.md + GORSEL_DENETIM/`. Eski çalışan dosyaları değiştirmeden koru.
3. GitHub'da yeni test dalı ve commit veya açık PR; komitte sürüm ve açık kalan eksikler. `main/index.html` üzerine otomatik merge yapma.
4. PASS/FAIL/BLOKELİ matrisi, dokunmatik ekran görselleri, hangi ölçüler/cihaz/işlev test edildiği, kayıt testi tipi. Yapamadığın testi başarı hanesine koyma.
5. Her aşama sonunda '3A tamam mı?' gibi net kabul sonucu. Tamamlanmadıysa yalnız açık kalan 3A'yı bitir; sonraki aşamaya geçme.

## KIRMIZI TAKIM — YAPMAMAN GEREKENLER
- 'İstenen her şey yapıldı' deyip gerçek test veya kod olmadan teslim etme.
- Ödül popup'ıyla eski ikinci onay ekranını geri getirme; çiçeği joystick yapma.
- Tek dosya kaynakta render/frame döngüsünü kırma, karekterin yönlerini ters çevirme, paket içi img base64 varlıklarını kaybetme.
- Mevcut 3.24'ün 10 ana/5 devam/3 yan görevini silme.
- Yeni seviye/ekonomi formüllerini test etmeden eski kullanıcılara dayatma.
- Gerçek çok oyunculu server olmadan online etiket koyma.

**BAŞLA:** Önce 3.24 kaynağını ve GitHub kesin şartnamesini analiz et. 3A'daki gerçek hataları bul, kök nedenlerden düzelt, TEST ET, yalnız kanıtlı sonucu ayrı HTML ve ZIP olarak teslim et. 3A kabul edilmeden yeni sistem geliştirme.
