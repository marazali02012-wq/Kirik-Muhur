# KIRIK MÜHÜR — Eksikler ve doğrulanma durumu

**Kaynak:** GitHub 3.24 izole test sürümü, kesin şartname ve önceki test raporları. Bu liste tamamlanan bir iş raporu DEĞİLDİR.

## Şimdi eksik olan — 3A
- [ ] Android fiziksel cihazda dokunma, dönüş, yürüyüş ve uzun süreli oyun kabulü
- [ ] Gerçek HTTPS site origin'inde oyunu kapat/aç, `localStorage` doğrulaması; mevcut testler sahte depolamaya dayanıyor
- [ ] Ödülün otomatik NPC teslimi sonrasında **bilgilendirici popup'ı** gösterdiği gerçek akış testi ve gerekirse düzeltme
- [ ] İstisna durumları: yanlış rota, portal, bölgeden çıkış, düşman ölümü, manuel devralma, ölüm/yeniden doğma, kaydet/geri yükle
- [ ] Eski oyun açıklamaları ile gerçek oynanışın uyumu; başlangıçta kararma, HUD dokunma çakışması, kayıt geri yükleme

## Sonraki aşamalar — ASLA ŞİMDİ BİTMİŞ SAYMA
**3B:** Daha çok özgün bölge, NPC, yaratık, keşif ve yan görev; 10 ana+5 devam görevden gerçek derinliğe geçiş, görev çeşitliliği ve rota denetimi.

**3C:** XP/level güç/ekipman dengesi; seviyeye bağlı açılan ve yükseltilen beceriler; gerçek pet/binek büyüme/stat/animasyon; forge ve ganimet ekonomisi.

**3D:** Gerçek browser/Android kalıcı kayıt, uzun süreli crash/rota/boss/ödül regresyonu.

**3E:** Erkek/kadın karakter seçimi, 3 sınıf için büyük karakter önizlemesi, tematik giriş, adımlı Next Step; üç sahnede kaliteli özgün 2.5D/pixel-art; yoğun ama taşmayan HUD; şehir/hub; özgün ikonlar, doğru tuş ve animasyon.

**4+ (şimdilik kapalı):** Yeni boss/dungeon, world boss, gerçek lonca/sohbet/PvP, sunucu otoritesi, etkinlik/günlük/market/VIP. Gerçek backend olmadan çalışan multiplayer iddiası YOK.

## Kesin kararlar
- Görev başlangıcına **bir kez** dokunulduğunda otomatik av ve dönüş sürer; NPC'de ödül otomatik **tek kez** verilir. Ödül popup'ı karar sormaz, kazanımı bildirir.
- Çiçek menüleri değiştirir/gizler; joystick değildir.
- `main/index.html` ve önceki tüm kayıtlar korunur.
- Kırık Mühür başka oyunlara karıştırılmaz; Kung Fu Saga'dan görsel/isim/kod kopyalanmaz.

**Kaynak blob:** `b70de48f729e77fdd924711001ada641cb39b2d5`. Kaynağın değiştirilmediği SHA ile kontrol edilmelidir.
