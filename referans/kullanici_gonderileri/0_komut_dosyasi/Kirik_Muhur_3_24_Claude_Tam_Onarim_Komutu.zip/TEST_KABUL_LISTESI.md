# Claude dolduracak — 3A test/kanıt listesi

**Sürüm / commit / test ortamı / tarayıcı / Android cihaz modeli / tarih:** ______

| Kontrol | Beklenen | PASS / FAIL / BLOKELİ | Ekran görüntüsü veya log kanıtı |
|---|---|---|---|
| Kaynak JS | `node --check` hatasız | | |
| 3 sınıf | Muhafız, İzci, Dokumacı oyun açar | | |
| Portre ekran | 320×568, 360×800, 393×852, 412×915 taşma yok | | |
| Dokunmatik yürüme | Sağ/sol/çapraz, dönüş yönü ve animasyon tutarlı | | |
| Tek dokunuş görev | Hedef → savaş/toplama → ilgili NPC'ye otomatik dönüş | | |
| Manuel devralma | Hareket/oto savaş kapanır, kendiliğinden açılmaz | | |
| Dönüş devamı | Görev düğmesiyle kaldığı yerden sürer | | |
| Görev ödülü | Altın/XP/toz/eşya **tek kez** eklenir | | |
| Bilgi popup | Otomatik ödülden sonra kazanım gösterir, onay istemez | | |
| Yan görevler | 3 yan hedef için doğru sayım, tek ödül | | |
| Ana/devam görevleri | 10 ana + 5 devam görev takılmadan çalışır | | |
| Harita rotası | Yanlış bölge / portal / NPC dönüşü takılmaz | | |
| Düşman/ölüm | Ölme, yeniden doğma, beceri, boss ve hasar akışı | | |
| Çiçek hızlı menü | Menüleri değiştirir/gizler, joystick değildir | | |
| Tarayıcı kayıt | HTTPS'te kapat/aç/geri yükle gerçek `localStorage` | | |
| Eski kayıt | Önceki sürüm verisi bozulmadan geçer | | |
| Android cihaz | Fiziksel telefonda dokunma/geri tuşu/uzun oturum | | |
| Değişiklik güvenliği | main/index.html, eski HTML ve eski kayıt anahtarları korunur | | |

**AŞAMA 3A KABUL DURUMU:** [ ] KABUL EDİLDİ / [ ] AÇIK — neden: ______
**Sıradaki aşamaya geçiş izni:** 3A kabul edilmeden HAYIR.
